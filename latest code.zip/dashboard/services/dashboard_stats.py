"""
Dashboard Statistics
"""

import pandas as pd


class DashboardStats:

    @staticmethod
    def summary(df: pd.DataFrame):

        if df.empty:
            return {
                "bullish": 0,
                "bearish": 0,
                "neutral": 0,
                "avg_score": 0,
                "avg_rsi": 0,
            }

        bullish = (df["1D Trend"] == "Bullish").sum()
        bearish = (df["1D Trend"] == "Bearish").sum()
        neutral = (df["1D Trend"] == "Neutral").sum()

        return {
            "bullish": bullish,
            "bearish": bearish,
            "neutral": neutral,
            "avg_score": round(df["Score"].mean(), 1),
            "avg_rsi": round(df["1D RSI"].mean(), 1),
        }

    @staticmethod
    def top_opportunities(df: pd.DataFrame):

        if df.empty:
            return df

        return (
            df.sort_values("Score", ascending=False)
              .head(10)[
                  [
                      "Asset",
                      "Score",
                      "1D Trend",
                      "1D RSI",
                  ]
              ]
        )