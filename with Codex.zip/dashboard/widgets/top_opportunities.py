import streamlit as st


class TopOpportunities:

    @staticmethod
    def render(df):

        if df.empty:
            return

        st.subheader("⭐ Top Opportunities")

        cols = [
            "Ticker",
            "Signal",
            "AI Score",
            "Trend",
            "RSI",
            "Price",
        ]

        show = df[cols].sort_values(
            "AI Score",
            ascending=False
        ).head(10)

        st.dataframe(
            show,
            use_container_width=True,
            hide_index=True,
            height=370,
        )