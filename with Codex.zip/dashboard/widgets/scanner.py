import streamlit as st
import pandas as pd


class Scanner:

    @staticmethod
    def color_price(v):
        if pd.isna(v):
            return ""

        if v > 0:
            return "color:green;font-weight:bold;"

        if v < 0:
            return "color:red;font-weight:bold;"

        return ""

    @staticmethod
    def color_signal(v):

        if pd.isna(v):
            return ""

        v = str(v).lower()

        if "strong buy" in v:
            return "background-color:#00b050;color:white"

        if "buy" in v:
            return "background-color:#92d050"

        if "sell" in v:
            return "background-color:#ff6666"

        if "strong sell" in v:
            return "background-color:#c00000;color:white"

        return ""

    @staticmethod
    def render(df):

        if df.empty:

            st.warning("No assets found.")

            return

        st.subheader("🔍 Market Scanner")

        styled = (
            df.style
            .map(
                Scanner.color_price,
                subset=["15m %","1H %","1D %"]
            )
            .map(
                Scanner.color_signal,
                subset=["Signal"]
            )
        )

        st.dataframe(
            styled,
            use_container_width=True,
            hide_index=True,
            height=700,
        )